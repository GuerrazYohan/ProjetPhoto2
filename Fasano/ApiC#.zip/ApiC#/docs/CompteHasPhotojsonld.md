# IO.Swagger.Model.CompteHasPhotojsonld
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Context** | **string** |  | [optional] 
**Id** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**CompteIdcompte** | **string** |  | [optional] 
**EvenementsIdevenements** | **string** |  | [optional] 
**PhotoIdphoto** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

