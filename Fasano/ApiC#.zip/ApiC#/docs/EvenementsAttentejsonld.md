# IO.Swagger.Model.EvenementsAttentejsonld
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Context** | **string** |  | [optional] 
**Id** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**IdevenementsAttente** | **int?** |  | [optional] 
**Nom** | **string** |  | [optional] 
**Datedebut** | **DateTime?** |  | [optional] 
**Datedefin** | **DateTime?** |  | [optional] 
**Motdepasseevent** | **string** |  | [optional] 
**Idcompte** | **int?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

