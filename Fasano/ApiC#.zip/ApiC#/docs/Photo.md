# IO.Swagger.Model.Photo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Idphoto** | **int?** |  | [optional] 
**Chemindacces** | **string** |  | [optional] 
**Rawbytesqr** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

