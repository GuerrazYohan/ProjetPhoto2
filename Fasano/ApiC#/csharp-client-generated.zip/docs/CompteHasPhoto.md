# IO.Swagger.Model.CompteHasPhoto
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CompteIdcompte** | **string** |  | [optional] 
**EvenementsIdevenements** | **string** |  | [optional] 
**PhotoIdphoto** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

