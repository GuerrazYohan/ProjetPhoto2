# IO.Swagger.Model.Evenements
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Idevenements** | **int?** |  | [optional] 
**Nom** | **string** |  | [optional] 
**Datedebut** | **DateTime?** |  | [optional] 
**Datedefin** | **DateTime?** |  | [optional] 
**Motdepasseevent** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

