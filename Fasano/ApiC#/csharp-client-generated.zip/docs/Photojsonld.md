# IO.Swagger.Model.Photojsonld
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Context** | **string** |  | [optional] 
**Id** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**Idphoto** | **int?** |  | [optional] 
**Chemindacces** | **string** |  | [optional] 
**Rawbytesqr** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

