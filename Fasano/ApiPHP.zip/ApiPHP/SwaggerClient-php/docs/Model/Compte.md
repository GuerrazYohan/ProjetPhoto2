# Compte

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idcompte** | **int** |  | [optional] 
**nom** | **string** |  | [optional] 
**prenom** | **string** |  | [optional] 
**motdepasse** | **string** |  | [optional] 
**email** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

