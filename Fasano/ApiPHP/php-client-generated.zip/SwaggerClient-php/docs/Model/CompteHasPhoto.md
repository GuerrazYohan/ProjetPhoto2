# CompteHasPhoto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**compte_idcompte** | **string** |  | [optional] 
**evenements_idevenements** | **string** |  | [optional] 
**photo_idphoto** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

