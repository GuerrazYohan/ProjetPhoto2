# CompteJsonld

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | **string** |  | [optional] 
**id** | **string** |  | [optional] 
**type** | **string** |  | [optional] 
**idcompte** | **int** |  | [optional] 
**nom** | **string** |  | [optional] 
**prenom** | **string** |  | [optional] 
**motdepasse** | **string** |  | [optional] 
**email** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

