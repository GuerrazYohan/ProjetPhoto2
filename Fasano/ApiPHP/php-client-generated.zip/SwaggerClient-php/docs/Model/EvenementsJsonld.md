# EvenementsJsonld

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**context** | **string** |  | [optional] 
**id** | **string** |  | [optional] 
**type** | **string** |  | [optional] 
**idevenements** | **int** |  | [optional] 
**nom** | **string** |  | [optional] 
**datedebut** | [**\DateTime**](\DateTime.md) |  | [optional] 
**datedefin** | [**\DateTime**](\DateTime.md) |  | [optional] 
**motdepasseevent** | **string** |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

