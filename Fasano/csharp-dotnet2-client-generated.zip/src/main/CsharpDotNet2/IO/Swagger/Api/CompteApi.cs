using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ICompteApi
    {
        /// <summary>
        /// Removes the Compte resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        void DeleteCompteItem (string id);
        /// <summary>
        /// Retrieves the collection of Compte resources. 
        /// </summary>
        /// <param name="page">The collection page number</param>
        /// <returns>Object</returns>
        Object GetCompteCollection (int? page);
        /// <summary>
        /// Retrieves a Compte resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ComponentsschemasComptejsonld</returns>
        ComponentsschemasComptejsonld GetCompteItem (string id);
        /// <summary>
        /// Updates the Compte resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated Compte resource</param>
        /// <returns>ComponentsschemasComptejsonld</returns>
        ComponentsschemasComptejsonld PatchCompteItem (string id, Compte body);
        /// <summary>
        /// Creates a Compte resource. 
        /// </summary>
        /// <param name="body">The new Compte resource</param>
        /// <returns>ComponentsschemasComptejsonld</returns>
        ComponentsschemasComptejsonld PostCompteCollection (Compte body);
        /// <summary>
        /// Replaces the Compte resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated Compte resource</param>
        /// <returns>ComponentsschemasComptejsonld</returns>
        ComponentsschemasComptejsonld PutCompteItem (string id, Compte body);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class CompteApi : ICompteApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CompteApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public CompteApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="CompteApi"/> class.
        /// </summary>
        /// <returns></returns>
        public CompteApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Removes the Compte resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public void DeleteCompteItem (string id)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling DeleteCompteItem");
    
            var path = "/PhotoBoothProject/comptes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteCompteItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteCompteItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Retrieves the collection of Compte resources. 
        /// </summary>
        /// <param name="page">The collection page number</param>
        /// <returns>Object</returns>
        public Object GetCompteCollection (int? page)
        {
    
            var path = "/PhotoBoothProject/comptes";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetCompteCollection: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetCompteCollection: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Object) ApiClient.Deserialize(response.Content, typeof(Object), response.Headers);
        }
    
        /// <summary>
        /// Retrieves a Compte resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ComponentsschemasComptejsonld</returns>
        public ComponentsschemasComptejsonld GetCompteItem (string id)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling GetCompteItem");
    
            var path = "/PhotoBoothProject/comptes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetCompteItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetCompteItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasComptejsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasComptejsonld), response.Headers);
        }
    
        /// <summary>
        /// Updates the Compte resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated Compte resource</param>
        /// <returns>ComponentsschemasComptejsonld</returns>
        public ComponentsschemasComptejsonld PatchCompteItem (string id, Compte body)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PatchCompteItem");
    
            var path = "/PhotoBoothProject/comptes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PATCH, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PatchCompteItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PatchCompteItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasComptejsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasComptejsonld), response.Headers);
        }
    
        /// <summary>
        /// Creates a Compte resource. 
        /// </summary>
        /// <param name="body">The new Compte resource</param>
        /// <returns>ComponentsschemasComptejsonld</returns>
        public ComponentsschemasComptejsonld PostCompteCollection (Compte body)
        {
    
            var path = "/PhotoBoothProject/comptes";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PostCompteCollection: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PostCompteCollection: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasComptejsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasComptejsonld), response.Headers);
        }
    
        /// <summary>
        /// Replaces the Compte resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated Compte resource</param>
        /// <returns>ComponentsschemasComptejsonld</returns>
        public ComponentsschemasComptejsonld PutCompteItem (string id, Compte body)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PutCompteItem");
    
            var path = "/PhotoBoothProject/comptes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PutCompteItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PutCompteItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasComptejsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasComptejsonld), response.Headers);
        }
    
    }
}
