using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface ICompteHasPhotoApi
    {
        /// <summary>
        /// Removes the CompteHasPhoto resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        void DeleteCompteHasPhotoItem (string id);
        /// <summary>
        /// Retrieves the collection of CompteHasPhoto resources. 
        /// </summary>
        /// <param name="page">The collection page number</param>
        /// <returns>Object</returns>
        Object GetCompteHasPhotoCollection (int? page);
        /// <summary>
        /// Retrieves a CompteHasPhoto resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ComponentsschemasCompteHasPhotojsonld</returns>
        ComponentsschemasCompteHasPhotojsonld GetCompteHasPhotoItem (string id);
        /// <summary>
        /// Updates the CompteHasPhoto resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated CompteHasPhoto resource</param>
        /// <returns>ComponentsschemasCompteHasPhotojsonld</returns>
        ComponentsschemasCompteHasPhotojsonld PatchCompteHasPhotoItem (string id, CompteHasPhoto body);
        /// <summary>
        /// Creates a CompteHasPhoto resource. 
        /// </summary>
        /// <param name="body">The new CompteHasPhoto resource</param>
        /// <returns>ComponentsschemasCompteHasPhotojsonld</returns>
        ComponentsschemasCompteHasPhotojsonld PostCompteHasPhotoCollection (CompteHasPhoto body);
        /// <summary>
        /// Replaces the CompteHasPhoto resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated CompteHasPhoto resource</param>
        /// <returns>ComponentsschemasCompteHasPhotojsonld</returns>
        ComponentsschemasCompteHasPhotojsonld PutCompteHasPhotoItem (string id, CompteHasPhoto body);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class CompteHasPhotoApi : ICompteHasPhotoApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CompteHasPhotoApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public CompteHasPhotoApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="CompteHasPhotoApi"/> class.
        /// </summary>
        /// <returns></returns>
        public CompteHasPhotoApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Removes the CompteHasPhoto resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public void DeleteCompteHasPhotoItem (string id)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling DeleteCompteHasPhotoItem");
    
            var path = "/PhotoBoothProject/compte_has_photos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteCompteHasPhotoItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteCompteHasPhotoItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Retrieves the collection of CompteHasPhoto resources. 
        /// </summary>
        /// <param name="page">The collection page number</param>
        /// <returns>Object</returns>
        public Object GetCompteHasPhotoCollection (int? page)
        {
    
            var path = "/PhotoBoothProject/compte_has_photos";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetCompteHasPhotoCollection: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetCompteHasPhotoCollection: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Object) ApiClient.Deserialize(response.Content, typeof(Object), response.Headers);
        }
    
        /// <summary>
        /// Retrieves a CompteHasPhoto resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ComponentsschemasCompteHasPhotojsonld</returns>
        public ComponentsschemasCompteHasPhotojsonld GetCompteHasPhotoItem (string id)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling GetCompteHasPhotoItem");
    
            var path = "/PhotoBoothProject/compte_has_photos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetCompteHasPhotoItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetCompteHasPhotoItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasCompteHasPhotojsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasCompteHasPhotojsonld), response.Headers);
        }
    
        /// <summary>
        /// Updates the CompteHasPhoto resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated CompteHasPhoto resource</param>
        /// <returns>ComponentsschemasCompteHasPhotojsonld</returns>
        public ComponentsschemasCompteHasPhotojsonld PatchCompteHasPhotoItem (string id, CompteHasPhoto body)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PatchCompteHasPhotoItem");
    
            var path = "/PhotoBoothProject/compte_has_photos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PATCH, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PatchCompteHasPhotoItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PatchCompteHasPhotoItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasCompteHasPhotojsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasCompteHasPhotojsonld), response.Headers);
        }
    
        /// <summary>
        /// Creates a CompteHasPhoto resource. 
        /// </summary>
        /// <param name="body">The new CompteHasPhoto resource</param>
        /// <returns>ComponentsschemasCompteHasPhotojsonld</returns>
        public ComponentsschemasCompteHasPhotojsonld PostCompteHasPhotoCollection (CompteHasPhoto body)
        {
    
            var path = "/PhotoBoothProject/compte_has_photos";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PostCompteHasPhotoCollection: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PostCompteHasPhotoCollection: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasCompteHasPhotojsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasCompteHasPhotojsonld), response.Headers);
        }
    
        /// <summary>
        /// Replaces the CompteHasPhoto resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated CompteHasPhoto resource</param>
        /// <returns>ComponentsschemasCompteHasPhotojsonld</returns>
        public ComponentsschemasCompteHasPhotojsonld PutCompteHasPhotoItem (string id, CompteHasPhoto body)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PutCompteHasPhotoItem");
    
            var path = "/PhotoBoothProject/compte_has_photos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PutCompteHasPhotoItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PutCompteHasPhotoItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasCompteHasPhotojsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasCompteHasPhotojsonld), response.Headers);
        }
    
    }
}
