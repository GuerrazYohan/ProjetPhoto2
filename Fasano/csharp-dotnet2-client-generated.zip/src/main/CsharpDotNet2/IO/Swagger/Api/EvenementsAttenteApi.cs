using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IEvenementsAttenteApi
    {
        /// <summary>
        /// Removes the EvenementsAttente resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        void DeleteEvenementsAttenteItem (string id);
        /// <summary>
        /// Retrieves the collection of EvenementsAttente resources. 
        /// </summary>
        /// <param name="page">The collection page number</param>
        /// <returns>Object</returns>
        Object GetEvenementsAttenteCollection (int? page);
        /// <summary>
        /// Retrieves a EvenementsAttente resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ComponentsschemasEvenementsAttentejsonld</returns>
        ComponentsschemasEvenementsAttentejsonld GetEvenementsAttenteItem (string id);
        /// <summary>
        /// Updates the EvenementsAttente resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated EvenementsAttente resource</param>
        /// <returns>ComponentsschemasEvenementsAttentejsonld</returns>
        ComponentsschemasEvenementsAttentejsonld PatchEvenementsAttenteItem (string id, EvenementsAttente body);
        /// <summary>
        /// Creates a EvenementsAttente resource. 
        /// </summary>
        /// <param name="body">The new EvenementsAttente resource</param>
        /// <returns>ComponentsschemasEvenementsAttentejsonld</returns>
        ComponentsschemasEvenementsAttentejsonld PostEvenementsAttenteCollection (EvenementsAttente body);
        /// <summary>
        /// Replaces the EvenementsAttente resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated EvenementsAttente resource</param>
        /// <returns>ComponentsschemasEvenementsAttentejsonld</returns>
        ComponentsschemasEvenementsAttentejsonld PutEvenementsAttenteItem (string id, EvenementsAttente body);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class EvenementsAttenteApi : IEvenementsAttenteApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EvenementsAttenteApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public EvenementsAttenteApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="EvenementsAttenteApi"/> class.
        /// </summary>
        /// <returns></returns>
        public EvenementsAttenteApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Removes the EvenementsAttente resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public void DeleteEvenementsAttenteItem (string id)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling DeleteEvenementsAttenteItem");
    
            var path = "/PhotoBoothProject/evenements_attentes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteEvenementsAttenteItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DeleteEvenementsAttenteItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Retrieves the collection of EvenementsAttente resources. 
        /// </summary>
        /// <param name="page">The collection page number</param>
        /// <returns>Object</returns>
        public Object GetEvenementsAttenteCollection (int? page)
        {
    
            var path = "/PhotoBoothProject/evenements_attentes";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEvenementsAttenteCollection: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEvenementsAttenteCollection: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Object) ApiClient.Deserialize(response.Content, typeof(Object), response.Headers);
        }
    
        /// <summary>
        /// Retrieves a EvenementsAttente resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ComponentsschemasEvenementsAttentejsonld</returns>
        public ComponentsschemasEvenementsAttentejsonld GetEvenementsAttenteItem (string id)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling GetEvenementsAttenteItem");
    
            var path = "/PhotoBoothProject/evenements_attentes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEvenementsAttenteItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetEvenementsAttenteItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasEvenementsAttentejsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasEvenementsAttentejsonld), response.Headers);
        }
    
        /// <summary>
        /// Updates the EvenementsAttente resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated EvenementsAttente resource</param>
        /// <returns>ComponentsschemasEvenementsAttentejsonld</returns>
        public ComponentsschemasEvenementsAttentejsonld PatchEvenementsAttenteItem (string id, EvenementsAttente body)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PatchEvenementsAttenteItem");
    
            var path = "/PhotoBoothProject/evenements_attentes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PATCH, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PatchEvenementsAttenteItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PatchEvenementsAttenteItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasEvenementsAttentejsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasEvenementsAttentejsonld), response.Headers);
        }
    
        /// <summary>
        /// Creates a EvenementsAttente resource. 
        /// </summary>
        /// <param name="body">The new EvenementsAttente resource</param>
        /// <returns>ComponentsschemasEvenementsAttentejsonld</returns>
        public ComponentsschemasEvenementsAttentejsonld PostEvenementsAttenteCollection (EvenementsAttente body)
        {
    
            var path = "/PhotoBoothProject/evenements_attentes";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PostEvenementsAttenteCollection: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PostEvenementsAttenteCollection: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasEvenementsAttentejsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasEvenementsAttentejsonld), response.Headers);
        }
    
        /// <summary>
        /// Replaces the EvenementsAttente resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated EvenementsAttente resource</param>
        /// <returns>ComponentsschemasEvenementsAttentejsonld</returns>
        public ComponentsschemasEvenementsAttentejsonld PutEvenementsAttenteItem (string id, EvenementsAttente body)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PutEvenementsAttenteItem");
    
            var path = "/PhotoBoothProject/evenements_attentes/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PutEvenementsAttenteItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PutEvenementsAttenteItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasEvenementsAttentejsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasEvenementsAttentejsonld), response.Headers);
        }
    
    }
}
