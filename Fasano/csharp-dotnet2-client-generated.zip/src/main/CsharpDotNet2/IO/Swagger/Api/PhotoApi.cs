using System;
using System.Collections.Generic;
using RestSharp;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace IO.Swagger.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IPhotoApi
    {
        /// <summary>
        /// Removes the Photo resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        void DeletePhotoItem (string id);
        /// <summary>
        /// Retrieves the collection of Photo resources. 
        /// </summary>
        /// <param name="page">The collection page number</param>
        /// <returns>Object</returns>
        Object GetPhotoCollection (int? page);
        /// <summary>
        /// Retrieves a Photo resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ComponentsschemasPhotojsonld</returns>
        ComponentsschemasPhotojsonld GetPhotoItem (string id);
        /// <summary>
        /// Updates the Photo resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated Photo resource</param>
        /// <returns>ComponentsschemasPhotojsonld</returns>
        ComponentsschemasPhotojsonld PatchPhotoItem (string id, Photo body);
        /// <summary>
        /// Creates a Photo resource. 
        /// </summary>
        /// <param name="body">The new Photo resource</param>
        /// <returns>ComponentsschemasPhotojsonld</returns>
        ComponentsschemasPhotojsonld PostPhotoCollection (Photo body);
        /// <summary>
        /// Replaces the Photo resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated Photo resource</param>
        /// <returns>ComponentsschemasPhotojsonld</returns>
        ComponentsschemasPhotojsonld PutPhotoItem (string id, Photo body);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class PhotoApi : IPhotoApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PhotoApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public PhotoApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="PhotoApi"/> class.
        /// </summary>
        /// <returns></returns>
        public PhotoApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }
    
        /// <summary>
        /// Sets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public void SetBasePath(String basePath)
        {
            this.ApiClient.BasePath = basePath;
        }
    
        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Removes the Photo resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public void DeletePhotoItem (string id)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling DeletePhotoItem");
    
            var path = "/PhotoBoothProject/photos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.DELETE, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling DeletePhotoItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling DeletePhotoItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return;
        }
    
        /// <summary>
        /// Retrieves the collection of Photo resources. 
        /// </summary>
        /// <param name="page">The collection page number</param>
        /// <returns>Object</returns>
        public Object GetPhotoCollection (int? page)
        {
    
            var path = "/PhotoBoothProject/photos";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             if (page != null) queryParams.Add("page", ApiClient.ParameterToString(page)); // query parameter
                                        
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetPhotoCollection: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetPhotoCollection: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Object) ApiClient.Deserialize(response.Content, typeof(Object), response.Headers);
        }
    
        /// <summary>
        /// Retrieves a Photo resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ComponentsschemasPhotojsonld</returns>
        public ComponentsschemasPhotojsonld GetPhotoItem (string id)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling GetPhotoItem");
    
            var path = "/PhotoBoothProject/photos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling GetPhotoItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling GetPhotoItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasPhotojsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasPhotojsonld), response.Headers);
        }
    
        /// <summary>
        /// Updates the Photo resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated Photo resource</param>
        /// <returns>ComponentsschemasPhotojsonld</returns>
        public ComponentsschemasPhotojsonld PatchPhotoItem (string id, Photo body)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PatchPhotoItem");
    
            var path = "/PhotoBoothProject/photos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PATCH, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PatchPhotoItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PatchPhotoItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasPhotojsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasPhotojsonld), response.Headers);
        }
    
        /// <summary>
        /// Creates a Photo resource. 
        /// </summary>
        /// <param name="body">The new Photo resource</param>
        /// <returns>ComponentsschemasPhotojsonld</returns>
        public ComponentsschemasPhotojsonld PostPhotoCollection (Photo body)
        {
    
            var path = "/PhotoBoothProject/photos";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PostPhotoCollection: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PostPhotoCollection: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasPhotojsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasPhotojsonld), response.Headers);
        }
    
        /// <summary>
        /// Replaces the Photo resource. 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="body">The updated Photo resource</param>
        /// <returns>ComponentsschemasPhotojsonld</returns>
        public ComponentsschemasPhotojsonld PutPhotoItem (string id, Photo body)
        {
            // verify the required parameter 'id' is set
            if (id == null) throw new ApiException(400, "Missing required parameter 'id' when calling PutPhotoItem");
    
            var path = "/PhotoBoothProject/photos/{id}";
            path = path.Replace("{format}", "json");
            path = path.Replace("{" + "id" + "}", ApiClient.ParameterToString(id));
    
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                                postBody = ApiClient.Serialize(body); // http body (model) parameter
    
            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.PUT, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling PutPhotoItem: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling PutPhotoItem: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ComponentsschemasPhotojsonld) ApiClient.Deserialize(response.Content, typeof(ComponentsschemasPhotojsonld), response.Headers);
        }
    
    }
}
