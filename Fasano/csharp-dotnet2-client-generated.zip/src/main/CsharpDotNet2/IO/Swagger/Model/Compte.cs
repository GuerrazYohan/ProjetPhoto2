using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// Compte
  /// </summary>
  [DataContract]
  public class Compte {
    /// <summary>
    /// Gets or Sets Idcompte
    /// </summary>
    [DataMember(Name="idcompte", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "idcompte")]
    public int? Idcompte { get; set; }

    /// <summary>
    /// Gets or Sets Nom
    /// </summary>
    [DataMember(Name="nom", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "nom")]
    public string Nom { get; set; }

    /// <summary>
    /// Gets or Sets Prenom
    /// </summary>
    [DataMember(Name="prenom", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "prenom")]
    public string Prenom { get; set; }

    /// <summary>
    /// Gets or Sets Motdepasse
    /// </summary>
    [DataMember(Name="motdepasse", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "motdepasse")]
    public string Motdepasse { get; set; }

    /// <summary>
    /// Gets or Sets Email
    /// </summary>
    [DataMember(Name="email", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "email")]
    public string Email { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Compte {\n");
      sb.Append("  Idcompte: ").Append(Idcompte).Append("\n");
      sb.Append("  Nom: ").Append(Nom).Append("\n");
      sb.Append("  Prenom: ").Append(Prenom).Append("\n");
      sb.Append("  Motdepasse: ").Append(Motdepasse).Append("\n");
      sb.Append("  Email: ").Append(Email).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
