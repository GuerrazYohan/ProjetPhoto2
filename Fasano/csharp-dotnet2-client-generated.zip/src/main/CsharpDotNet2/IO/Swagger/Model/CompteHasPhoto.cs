using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// CompteHasPhoto
  /// </summary>
  [DataContract]
  public class CompteHasPhoto {
    /// <summary>
    /// Gets or Sets CompteIdcompte
    /// </summary>
    [DataMember(Name="compteIdcompte", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "compteIdcompte")]
    public string CompteIdcompte { get; set; }

    /// <summary>
    /// Gets or Sets EvenementsIdevenements
    /// </summary>
    [DataMember(Name="evenementsIdevenements", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "evenementsIdevenements")]
    public string EvenementsIdevenements { get; set; }

    /// <summary>
    /// Gets or Sets PhotoIdphoto
    /// </summary>
    [DataMember(Name="photoIdphoto", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "photoIdphoto")]
    public string PhotoIdphoto { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class CompteHasPhoto {\n");
      sb.Append("  CompteIdcompte: ").Append(CompteIdcompte).Append("\n");
      sb.Append("  EvenementsIdevenements: ").Append(EvenementsIdevenements).Append("\n");
      sb.Append("  PhotoIdphoto: ").Append(PhotoIdphoto).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
