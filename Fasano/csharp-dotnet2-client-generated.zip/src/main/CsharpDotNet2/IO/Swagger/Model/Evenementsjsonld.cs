using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace IO.Swagger.Model {

  /// <summary>
  /// Evenements
  /// </summary>
  [DataContract]
  public class Evenementsjsonld {
    /// <summary>
    /// Gets or Sets Context
    /// </summary>
    [DataMember(Name="@context", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "@context")]
    public string Context { get; set; }

    /// <summary>
    /// Gets or Sets Id
    /// </summary>
    [DataMember(Name="@id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "@id")]
    public string Id { get; set; }

    /// <summary>
    /// Gets or Sets Type
    /// </summary>
    [DataMember(Name="@type", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "@type")]
    public string Type { get; set; }

    /// <summary>
    /// Gets or Sets Idevenements
    /// </summary>
    [DataMember(Name="idevenements", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "idevenements")]
    public int? Idevenements { get; set; }

    /// <summary>
    /// Gets or Sets Nom
    /// </summary>
    [DataMember(Name="nom", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "nom")]
    public string Nom { get; set; }

    /// <summary>
    /// Gets or Sets Datedebut
    /// </summary>
    [DataMember(Name="datedebut", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "datedebut")]
    public DateTime? Datedebut { get; set; }

    /// <summary>
    /// Gets or Sets Datedefin
    /// </summary>
    [DataMember(Name="datedefin", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "datedefin")]
    public DateTime? Datedefin { get; set; }

    /// <summary>
    /// Gets or Sets Motdepasseevent
    /// </summary>
    [DataMember(Name="motdepasseevent", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "motdepasseevent")]
    public string Motdepasseevent { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Evenementsjsonld {\n");
      sb.Append("  Context: ").Append(Context).Append("\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  Type: ").Append(Type).Append("\n");
      sb.Append("  Idevenements: ").Append(Idevenements).Append("\n");
      sb.Append("  Nom: ").Append(Nom).Append("\n");
      sb.Append("  Datedebut: ").Append(Datedebut).Append("\n");
      sb.Append("  Datedefin: ").Append(Datedefin).Append("\n");
      sb.Append("  Motdepasseevent: ").Append(Motdepasseevent).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
